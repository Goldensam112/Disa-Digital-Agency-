DISA DIGITAL AGENCY — MULTI-PAGE WEBSITE PACKAGE — CLEANED BUILD

PRIMARY CANONICAL HOST
This package uses https://www.disadigital.online/ consistently in canonical tags, Open Graph URLs, structured data and sitemap because the currently indexed public site appears on the www host. Before upload, confirm hosting redirects non-www to www. If hosting redirects the other way, change the canonical host consistently in every file and sitemap.

PAGES
- index.html — concise agency homepage
- services.html, website-development.html, app-development.html, digital-marketing.html, seo-services.html
- google-ads.html, social-media-marketing.html, branding-design.html
- products.html — Apna Kaam, Disa Online, PULSE5 (Pulse Chat), selected client work and Disa Digital Study course link
- portfolio.html, about.html, contact.html, faq.html, insights.html
- local-seo-bhopal.html, website-cost-guide.html, google-ads-landing-page-guide.html
- disa-digital-study.html
- privacy-policy.html, terms-and-conditions.html, cookie-policy.html, disclaimer.html, refund-policy.html
- assets/site.css, assets/site.js, favicon files, logo.svg, logo.png, og-image.png, site.webmanifest, sitemap.xml, robots.txt

DEPLOYMENT
1. Download and extract the ZIP; back up current public_html first.
2. Upload the CONTENTS of this folder to the hosting document root, preserving the assets folder and root-level HTML files.
3. Confirm https://www.disadigital.online/ is canonical and that non-www redirects to www. Test homepage, all page links, app links, WhatsApp form, mobile menu, favicon, og-image.png and sitemap.xml.
4. The contact form prepares a WhatsApp message in the visitor's browser. It does not submit to a website database or CRM.
5. Submit https://www.disadigital.online/sitemap.xml in Google Search Console and inspect the homepage and products page.
6. Test PageSpeed Insights, mobile Core Web Vitals and structured data after deployment. This ZIP does not itself prove a live performance score, indexing, ranking or AI Overview inclusion.

IMPORTANT CONTENT NOTES
- No invented client testimonials, ratings, ROAS figures, uptime guarantees or download counts are included.
- App summaries are based on public Google Play listings. The official Play Store pages remain the source of truth for current features, age ratings, Data safety disclosures and availability.
- Disa Online is clearly described as a private consultancy app, not a government app.
- Pulse app is labelled PULSE5 (Pulse Chat) to align the website with the current Google Play listing title.
- Disa Digital Study link is included; course fees and syllabus are not hard-coded because they should be checked on the official course website.
- MSME registration is described only as represented by the business; no registration number or government endorsement badge is fabricated.
- Privacy, terms, cookie and refund pages are starter copy. Review and customize them to actual data handling, payment, analytics and business processes before publishing.
- Confirm all business claims, client permissions, legal pages and course details before launch.

QUALITY-CONTROL NOTE
The HTML documents were normalized to one doctype each; duplicate breadcrumbs were removed where the hero already contains a breadcrumb; the Services page was reduced to six distinct service cards; the sitemap was regenerated from the HTML pages. Performance and indexing must still be verified after deployment.
